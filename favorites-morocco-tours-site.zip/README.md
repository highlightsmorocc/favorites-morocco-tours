# Favorites Morocco Tours — static website (HTML)

Bilingual (EN / ES) static version of [favoritesmoroccotours.com](https://favoritesmoroccotours.com), ready for GitHub Pages.

- `index.html` — English
- `es/index.html` — Español
- `assets/style.css`, `assets/main.js`

Tours link to the full itineraries on the main website. Forms send the request straight to WhatsApp (+212 786 278 943).
Canonical tags point to favoritesmoroccotours.com so this copy never competes with the main site in Google.

To regenerate the pages after editing texts: `python3 build.py`
